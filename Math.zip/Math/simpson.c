#include<stdio.h>
#include<math.h>
float f(float x);
void displayResult(float a,float b,float A,int n);
void getData(float* a,float*b,int * n);
float trapeze(float a,float b,int n);
float sum(float a,float b,int n);
float valeurAB(float a,float b);
float simpson(float a,float b,int n);
float sum2(float a,float b,int n);
int main(){
	printf("le calcule met trap");
////Entre de donnee
	float a=458 , b=1020;///borne de l'integration
	float A=12.325;/// reponse;
	int n=10;//le nb de sous-integration des discret
	getData(&a,&b,&n);
	
////Calcul
	///float h=(b-a)/n;
	/*int i=1;
	E=1.e-6;
	while(i<n){
		float A1=trapeze(a,b,n);
		float A2=trapeze(a,b,2n);
		float calc=valeurAB(A1,A2);
		if(calc<E){
			printf("rep=%f\n",A2);
		}
	}*/
	A=simpson(a,b,n);
    printf("%g\n",A);
////Sortie de resultat
	displayResult(a,b,A,n);
	return 0;

}
float valeurAB(float a,float b){
	float rep=a+b;
	if(rep<0){
		rep*-1;
	}
	return rep;
}
float simpson(float a,float b,int n){///Methode de simpson
	float A;
	float h=(b-a)/n;
	//A=(h/6)*
	A=(h/6)*(f(a)+2*sum(a,b,n)+f(b)+4*sum2(a,b,n));
	return A;
}
float trapeze(float a,float b,int n){////Methode de trapeze
	float A;
	float h=(b-a)/n;
	A=(h/2)* (f(a)+2*sum(a,b,n)+f(b));
	
	return A;
}
void getData(float* a,float *b,int*n){
	*a=0;
	*b=1;
	*n=20;
}
float sum(float a,float b,int n){
	float sum=0;
	float h=(b-a)/n;
	float xi=a;
	for(int i=1;i<n;i++){
		xi=a+h*i;
		sum+=f(xi);
	}
	return sum;
}
float sum2(float a,float b,int n){
	float sum2=0;
	float h=(b-a)/n;
	float xid=0;
	for(int i=0;i<n;i++){
		xid=(a+h*i)+h/2;
		sum2+=f(xid);

	}
	return sum2;
}
void displayResult(float a,float b,float A,int n){/////afficher les resultat
	printf("integrale de f dans [%g;%g] est A =%g\n",a,b,A);
	printf("\t en decoupant l'integrale en %i\n",n); 
} 

float f(float x){////Fonction a resoudre
	return exp(sin(5*x));
}

